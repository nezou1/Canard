public class Personne {

    private String nom;

    public Personne(){
        this.nom = nom;
    }
}

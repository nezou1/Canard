public class Animaux {

    protected String couleur;
    protected int points;

    private static int id = 0;

    public Animaux(){
        id +=1;
    }

    public static int getId(){ return id;}






}
